# Hướng dẫn dựng app iPhone / iPad "Nghịch Thiên Tiên Lộ" (tự build trên máy Mac)

Dành cho người không chuyên. Làm lần lượt từng bước. Mất khoảng 30–60 phút lần đầu (phần lớn là chờ tải Xcode).

## 0. Cần biết trước

- App này là **vỏ** mở game online. Game chạy từ máy chủ `https://play.nghichthien.top`; app tự cập nhật nội dung game, nên **chỉ cần build vỏ một lần**.
- **App chỉ dùng để ĐĂNG NHẬP và chơi. KHÔNG đăng ký tài khoản trong app.** Chưa có tài khoản thì đăng ký ở web **https://nghichthien.top/dang-ky**, rồi quay lại app đăng nhập. (Trong app có dòng "Chưa có tài khoản? Đăng ký tại nghichthien.top", bấm vào sẽ mở trình duyệt Safari.)
- Chơi **chiều ngang** (iPhone và iPad).
- Bạn cần: máy Mac (macOS 13 trở lên), Apple ID, iPhone/iPad + dây cáp, kết nối mạng.

### Hai kiểu tài khoản Apple, khác nhau thế nào

| | Apple ID MIỄN PHÍ ("Personal Team") | Apple Developer Program (99 USD/năm) |
|---|---|---|
| Cài lên máy của chính bạn | Được | Được |
| App chạy được bao lâu | **7 ngày**, sau đó phải cắm máy build/cài lại | 1 năm (Ad Hoc/Development), không hết hạn với TestFlight (90 ngày mỗi bản) / App Store |
| Số app tối đa | 3 app cùng lúc | Không giới hạn thực tế |
| Đưa cho người khác cài | **Không** | Có: TestFlight (tối đa 10.000 người thử) hoặc App Store |
| Xuất file .ipa | Chỉ để cài lên máy mình | Ad Hoc (100 máy đã đăng ký UDID) / TestFlight / App Store |

Nếu chỉ cài lên máy của bạn: dùng Apple ID miễn phí là đủ.
Muốn phát hành rộng: đăng ký Apple Developer Program (https://developer.apple.com/programs/), sau đó Product → Archive → Distribute App → TestFlight/App Store (xem mục 9).

## Bản này sửa gì (build 4, 25/11/2026)

Sửa lỗi **vệt trắng hai bên / dưới đáy và nút game thụt vào** trên iPhone có tai thỏ. Lỗi nằm ở cấu hình vỏ, nên **phải build lại .ipa và người chơi cài lại**.

- Giải nén vào **thư mục mới**, không chép đè lên thư mục cũ. Làm lại từ mục 3.
- Dùng **đúng Bundle ID và Team của lần trước** để cài đè được và giữ đăng nhập.
- Nếu đã từng up TestFlight / App Store với số build lớn hơn 4: tăng số **Build** ở thẻ General cho lớn hơn bản đã up.
- Sau khi chạy `npx cap sync ios`, kiểm nhanh (đang ở thư mục `client`):
  ```
  grep -E "contentInset|backgroundColor" ios/App/App/capacitor.config.json
  ```
  Phải thấy `never` và `#000000`. Nếu thấy `always` là đang dùng gói cũ.

## 1. Thông số của dự án (đừng sửa)

| Thông số | Giá trị |
|---|---|
| Tên hiển thị | Nghịch Thiên Tiên Lộ |
| Máy chủ (origin) | `https://play.nghichthien.top` |
| Đăng ký tài khoản | `https://nghichthien.top/dang-ky` (làm trên web, không làm trong app) |
| Khoá CÔNG KHAI kiểm chữ ký nội dung game (Ed25519) | `4a6af59e0ac588684c2ced10f3498af4f4f1fd165f096f734b1a05c9d875b0fb` |
| Bundle ID gốc | `vn.nghichthientienlo.app` (bạn phải ĐỔI thành tên riêng, xem mục 6) |
| Phiên bản vỏ | 1.0.2 (build 4) |
| iOS tối thiểu | 15.4 |
| Nội dung nhúng | `b-20261124-2044-96ed9daa` |
| Hướng màn hình | Chỉ ngang (đã cấu hình sẵn cho iPhone + iPad) |

Khoá công khai đã được ghi sẵn trong `client/shell/config/shell.config.json` — **không cần làm gì**. Gói này KHÔNG chứa khoá riêng hay mật khẩu nào (khoá riêng của dự án do chủ dự án giữ, không bao giờ cần ở máy bạn). Nếu app báo "chữ ký không hợp lệ", đó là dấu hiệu sai khoá: liên hệ chủ dự án, đừng tự đổi.

## 2. Cài công cụ (một lần)

1. **Xcode** (≥ 15): mở App Store trên Mac, tìm "Xcode", bấm Nhận/Cài (~10–15 GB). Mở Xcode một lần, đồng ý điều khoản, đợi nó "Installing components".
2. Cài công cụ dòng lệnh Xcode: mở **Terminal** (Cmd+Space, gõ Terminal), chạy:
   ```
   xcode-select --install
   sudo xcode-select -s /Applications/Xcode.app/Contents/Developer
   ```
3. **Homebrew** (nếu chưa có): làm theo https://brew.sh (copy 1 lệnh, dán vào Terminal).
4. **Node.js** (≥ 18, khuyên 20) và **CocoaPods**:
   ```
   brew install node cocoapods
   node -v      # phải ≥ v18
   pod --version
   ```

## 3. Giải nén và chuẩn bị mã

1. Giải nén `nttl-ios-source.zip` vào một thư mục, ví dụ `~/nttl-ios`. **Đừng để đường dẫn có dấu tiếng Việt hoặc dấu cách** (dễ lỗi).
2. Mở Terminal:
   ```
   cd ~/nttl-ios/client
   npm ci
   node shell/scripts/prepare.mjs --base base-goc
   npx cap sync ios
   ```
   - `npm ci`: tải thư viện (cần mạng, 1–3 phút).
   - `prepare.mjs`: gói launcher + "bản gốc" nội dung game (thư mục `base-goc`) vào app. Thấy dòng `[prepare] RELEASE origin=https://play.nghichthien.top ...` là đúng. Nếu báo "keys rỗng" hoặc "origin còn là miền mẫu": bạn giải nén sai gói, hãy giải nén lại.
   - `cap sync ios`: chép vào dự án iOS và chạy `pod install` (1–5 phút). Phải kết thúc bằng "Sync finished".
   - **Không cần chạy `npx cap add ios`**: dự án iOS (`client/ios`) đã có sẵn trong gói, đã cấu hình chỉ-ngang, iPhone+iPad, ATS an toàn, biểu tượng. Nếu bạn lỡ chạy mà báo "ios platform already exists" là bình thường, bỏ qua. (Chỉ chạy `cap add ios` nếu thư mục `ios` bị mất — khi đó phải đặt lại hướng ngang và TARGETED_DEVICE_FAMILY = 1,2 như mục 6–7.)

## 4. Mở bằng Xcode

```
open ios/App/App.xcworkspace
```
**Phải mở file `.xcworkspace`** (không phải `.xcodeproj`), nếu không sẽ thiếu thư viện.

## 5. Đặt Team (tài khoản ký)

1. Xcode → menu **Xcode → Settings… → Accounts** → dấu **+** → **Apple ID** → đăng nhập Apple ID của bạn. Xuất hiện dòng "(Personal Team)" nếu là tài khoản miễn phí.
2. Cột trái chọn project **App** (biểu tượng xanh trên cùng) → mục **TARGETS → App** → thẻ **Signing & Capabilities**.
3. Tick **Automatically manage signing**, ở **Team** chọn tên bạn (Personal Team) hoặc team Developer Program.

## 6. Bundle Identifier duy nhất

Cũng ở thẻ Signing & Capabilities, ô **Bundle Identifier**: đổi thành chuỗi **chưa ai dùng**, ví dụ `vn.nghichthientienlo.app.tenban` (chữ thường, không dấu, không cách, vd `vn.nghichthientienlo.app.minhhai`). Nếu báo "Failed to register bundle identifier / not available" thì thêm số: `...tenban2`.

Đổi Bundle ID **không ảnh hưởng** việc đăng nhập hay chơi game.

## 7. Kiểm hướng màn hình và loại thiết bị (đã đặt sẵn, chỉ để chắc)

- Thẻ **General** → **Deployment Info**: **iPhone** và **iPad** đều được tick; **Device Orientation** chỉ tick **Landscape Left** và **Landscape Right** (bỏ Portrait, Upside Down).
- Thẻ **Build Settings** → tìm `Targeted Device Family` phải là `iPhone, iPad` (giá trị 1,2).
- **Minimum Deployments** iOS **15.4** (đã đặt sẵn, đừng hạ xuống).

## 8. Chạy lên máy thật (cách nhanh nhất)

1. Cắm iPhone/iPad vào Mac bằng cáp, mở khoá máy, bấm **Tin cậy / Trust** trên máy.
2. **iOS 16 trở lên: bật Developer Mode** trên máy: **Cài đặt → Quyền riêng tư & Bảo mật → Chế độ nhà phát triển (Developer Mode)** → bật → máy khởi động lại → xác nhận. (Mục này chỉ hiện sau khi máy từng được cắm vào Xcode; nếu không thấy, cắm lại và bấm Run một lần rồi vào lại.)
3. Ở thanh trên cùng của Xcode, chọn tên thiết bị của bạn (không chọn "Any iOS Device").
4. Bấm nút **▶ Run** (hoặc Cmd+R). Lần đầu mất vài phút.
5. App xuất hiện trên màn hình chính. Nếu bấm vào báo **"Nhà phát triển chưa tin cậy" (Untrusted Developer)**: **Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị** (hoặc "Quản lý thiết bị") → chọn Apple ID của bạn → **Tin cậy**.
6. Mở app → màn hình đăng nhập → nhập tài khoản (đã đăng ký ở web) → chơi. Muốn thử trên iPad: chọn iPad (hoặc Simulator iPad) ở bước 3.

Thử trên **Simulator** (không cần máy thật): chọn một iPhone/iPad Simulator ở thanh trên → Run.

### 8b. BẮT BUỘC: kiểm trên iPhone thật trước khi gửi .ipa cho ai

Bản này sửa lỗi mất hình trong game trên iOS. Mới thử bằng WebKit trên máy tính, **chưa thử trên iPhone thật**. Dùng tài khoản thử, làm đủ các bước, chụp màn hình gửi chủ dự án:

| # | Việc | Phải thấy |
|---|---|---|
| 1 | Mở app lần đầu (có mạng) | Màn đăng nhập đủ hình, không có "Cần cập nhật" |
| 2 | Đăng nhập, vào làng | Màn tải có thanh tiến độ, rồi **nhân vật, NPC, nhà, nền map có hình thật**. Nếu là **khối màu be / xanh, icon vỡ hoặc ô xanh lá gạch chéo** thì CHƯA ĐẠT: dừng, chụp gửi chủ dự án |
| 3 | Mở Túi, Nhân Vật, Hoạt Động | Icon đủ, không ô vỡ |
| 4 | Đánh quái 2 phút, qua cổng sang map khác rồi quay lại | Hình đủ, có tiếng, không văng |
| 5 | Ra màn hình chính 1 phút, mở lại | Chơi tiếp được (hoặc bấm Tải lại là vào được) |
| 6 | Tắt hẳn app, mở lại | Vào nhanh hơn lần đầu, hình đủ |
| 7 | Trên iPhone có tai thỏ, xoay ngang **cả hai chiều**: xem màn đăng nhập, trong làng, mở Túi | Hình tràn hết màn hình, **không có vệt trắng**; nút, bản đồ nhỏ, cần điều khiển không bị tai thỏ che và không thụt quá xa mép. Chụp cả hai chiều |

Đạt cả 7 mới xuất .ipa. Gửi kèm: đời máy, phiên bản iOS.

## 9. Xuất file .ipa (tuỳ chọn)

Chỉ cần nếu muốn gửi file cài (Ad Hoc / TestFlight / App Store). Với Apple ID miễn phí, file .ipa chỉ dùng cho chính máy bạn đã đăng ký.

1. Thiết bị chọn **Any iOS Device (arm64)**.
2. Menu **Product → Archive** (đợi vài phút) → cửa sổ Organizer hiện ra.
3. Chọn bản Archive → **Distribute App**:
   - **Development** hoặc **Ad Hoc**: xuất .ipa cài lên các máy đã đăng ký (Ad Hoc cần Developer Program + UDID máy). Chọn thư mục lưu → có file `App.ipa`.
   - **App Store Connect → Upload**: đẩy lên TestFlight/App Store (cần Developer Program 99 USD/năm). Khi nộp cần: ảnh chụp màn hình, chính sách quyền riêng tư (`https://nghichthien.top/quyen-rieng-tu`), khai báo mã hoá xuất khẩu (app dùng HTTPS: trả lời "có dùng mã hoá chuẩn"). App chỉ tải JS/HTML/tài nguyên chạy trong WebView, đúng quy định 2.5.2.
4. Cài .ipa lên máy: dùng **Apple Configurator** (Mac App Store) hoặc Xcode → Window → Devices and Simulators → kéo .ipa vào mục "Installed Apps".

## 10. Lỗi thường gặp

| Lỗi | Cách xử lý |
|---|---|
| `Signing for "App" requires a development team` | Làm lại mục 5, chọn Team. |
| `Failed to register bundle identifier` | Đổi Bundle ID khác (mục 6). |
| `No profiles for ... were found` / `Communication with Apple failed` | Kiểm tra đã đăng nhập Apple ID trong Settings → Accounts; có mạng; bấm "Try Again". |
| `Maximum number of apps / 3 app limit` (Apple ID miễn phí) | Xoá bớt app tự build cũ trên máy, hoặc đợi hết hạn 7 ngày. |
| `Could not find Developer Disk Image` / máy không hiện trong danh sách | Cập nhật Xcode lên bản mới hơn iOS của máy; cắm lại cáp; bấm Trust. |
| `Developer Mode disabled` | Bật Chế độ nhà phát triển (mục 8 bước 2). |
| App báo "Untrusted Developer" | Mục 8 bước 5. |
| App mở lên rồi tắt sau 7 ngày | Apple ID miễn phí chỉ có hiệu lực 7 ngày: cắm máy, bấm Run lại để cài lại (đăng nhập game vẫn giữ nếu cài đè cùng Bundle ID). |
| `pod: command not found` hoặc lỗi CocoaPods | `brew install cocoapods`, rồi `cd ~/nttl-ios/client && npx cap sync ios`. |
| `Unable to find module dependency / No such module Capacitor` | Bạn mở `.xcodeproj`; phải mở `App.xcworkspace`. Hoặc chạy lại `npx cap sync ios`. |
| `npm ci` lỗi mạng / hết hạn | Thử lại; kiểm tra `node -v` ≥ 18. |
| Màn hình tối đen khi mở app / treo ở logo | Kiểm tra mạng của máy. Lần đầu app dựng bản gốc rồi tải cập nhật tối đa ~20 giây. Thử tắt hẳn app (vuốt lên) và mở lại. |
| App báo "chữ ký không hợp lệ" / "Cần cập nhật ứng dụng" | Báo chủ dự án (không tự sửa khoá). |
| Vào game chỉ thấy khối màu, icon vỡ | Không tự sửa. Chụp màn hình, ghi đời máy + phiên bản iOS gửi chủ dự án. |
| Muốn đăng ký tài khoản mà không thấy nút | Đúng thiết kế: đăng ký ở web https://nghichthien.top/dang-ky , rồi đăng nhập trong app. |

## 11. Khi nào phải build lại?

Gần như **không bao giờ**: nội dung game tự cập nhật từ máy chủ. Chỉ build lại khi: (a) app Apple ID miễn phí hết 7 ngày, (b) chủ dự án thông báo có "phiên bản vỏ mới" (minShellVersion), (c) bạn muốn đưa lên TestFlight/App Store.

## 12. Có gì trong gói

```
nttl-ios-source/
  HUONG-DAN-IOS.md     (file này)
  client/
    package.json, package-lock.json, capacitor.config.json
    shell/               (launcher + cấu hình vỏ; shell/config/shell.config.json đã có khoá công khai + origin)
    ios/                 (dự án Xcode đã cấu hình)
    base-goc/            (nội dung game nhúng sẵn: ĐÚNG bản đang phát hành b-20261124-2044-96ed9daa; KHÔNG có gói mã hoá, KHÔNG có khoá)
    public/icons/        (biểu tượng nguồn)
```
