// nttl-shell.js: chạy TRONG trang game (bản bundle), dựng window.nttlShell giống vỏ Electron.
//   version, bundleVersion, packCache{get,put,has}, openExternal(url), ready(), checkForUpdate(), rollbackNow()
// Bundle phải có <script src="nttl-shell.js"></script> trong HTML entry (vỏ chép file này cạnh entry) và gọi nttlShell.ready()
// khi màn hình đăng nhập/boot đã dựng xong; quá hạn không ready thì tự quay lui bản trước.
import { createUpdater } from '../core/updater.js';
import { createPackCache, safeExternalUrl } from '../core/packcache.js';
import { fs, net, sha256Hex, verifyEd25519, openBundle, openExternalNative } from './adapters.js';

const cfg = window.__NTTL_CFG__ || {};
const up = createUpdater({ fs, net, sha256Hex, verifyEd25519, config: cfg });
const cache = createPackCache({ fs, sha256Hex, quotaBytes: cfg.packQuotaBytes || 256 * 1024 * 1024 });
let readyDone = false, timer = null;

async function rollbackNow(reason) {
  const r = await up.rollback(cfg.bundleVersion, reason);
  if (r) await openBundle(r.abs); // mở lại bản trước, không cần khởi động lại app
  return !!r;
}

if (cfg.trial) { // bản mới đang được thử: không ready trong thời hạn -> quay lui
  timer = setTimeout(() => { if (!readyDone) rollbackNow('hết ' + (cfg.readyTimeoutMs || 25000) + 'ms không báo ready').catch(console.error); }, cfg.readyTimeoutMs || 25000);
}

window.nttlShell = Object.freeze({
  kind: 'capacitor',
  version: cfg.shellVersion,
  bundleVersion: cfg.bundleVersion,
  packCache: Object.freeze({ get: cache.get, put: cache.put, has: cache.has }),
  openExternal(url) {
    const u = safeExternalUrl(url);
    if (!u) return Promise.reject(new Error('chỉ mở được liên kết https công khai'));
    return openExternalNative(u);
  },
  async ready() { readyDone = true; if (timer) clearTimeout(timer); return up.confirmReady(cfg.bundleVersion); },
  markReady() { return this.ready(); }, // cùng tên với vỏ Electron: client gọi markReady() ở cả hai vỏ
  /** Kiểm + tải bản mới ở nền; kết quả áp dụng ở lần mở app kế (không làm gián đoạn ván đang chơi). */
  checkForUpdate: () => up.update({ deadlineMs: 120000 }),
  rollbackNow,
});
