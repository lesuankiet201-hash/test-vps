// Trang khởi động của vỏ (webDir = shell-www/). Mỗi lần mở app: cài bản gốc nếu lần đầu (hoặc dựng lại nếu bản gốc nhúng mới hơn)
// -> thử cập nhật (có thời hạn) -> chọn bản (quay lui nếu bản thử hỏng) -> ghi nttl-shell.js vào thư mục bản -> setServerBasePath.
import { createUpdater } from '../core/updater.js';
import { utf8, fromUtf8 } from '../core/util.js';
import { fs, net, sha256Hex, verifyEd25519, openBundle, openExternalNative } from './adapters.js';

const $ = (id) => document.getElementById(id);
const say = (t) => { $('msg').textContent = t; };

async function localGet(rel) { // gói gốc nằm trong assets của app, cùng origin -> fetch thường
  const r = await fetch('./base/' + (rel.startsWith('f/') ? rel + '.bin' : rel));
  if (!r.ok) throw new Error('thiếu ' + rel + ' trong gói gốc');
  return new Uint8Array(await r.arrayBuffer());
}

/** Bước chuẩn bị bản gốc (09 §5.2 B2): lần đầu cài; đã có dữ liệu mà bản nhúng MỚI HƠN thì dựng lại (không bao giờ hạ cấp).
 *  Lỗi khi đã có bản chạy được thì giữ bản đang dùng. */
export async function prepareBase(up, baseGet, log = console) {
  if (!(await up.loadState())) { await up.installBase(baseGet); return { action: 'installed' }; }
  try {
    const b = await up.syncBase(baseGet);
    if (b.action === 'upgraded') log.info('[nttl] dựng lại từ bản gốc mới hơn', b.from, '->', b.version);
    return b;
  } catch (e) { log.warn('[nttl] không dựng lại được từ bản gốc, giữ bản đang dùng', e); return { action: 'error', error: e }; }
}

/** nttl-shell.js (cầu nối window.nttlShell) nằm cạnh index.html của bản; vỏ tự ghi, không nằm trong manifest.
 *  LUÔN ghi lại mỗi lần mở (09 §5.2 B3): sau khi cài đè APK, bản cũ không giữ cầu nối + cấu hình (shellVersion, trial) của vỏ cũ. */
export async function writeShellBridge(io, cfg, act, srcBytes) {
  const pre = 'window.__NTTL_CFG__=' + JSON.stringify({ ...cfg, bundleVersion: act.version, trial: act.trial }) + ';\n';
  await io.writeBytes(act.dir + '/nttl-shell.js', utf8(pre + fromUtf8(srcBytes)));
}

async function main() {
  const cfg = await (await fetch('./shell-config.json')).json();
  const up = createUpdater({
    fs, net, sha256Hex, verifyEd25519, config: cfg,
    onProgress: ({ bytes, total }) => { $('bar').style.width = (total ? Math.round((bytes / total) * 100) : 0) + '%'; },
  });

  say('Đang chuẩn bị...');
  await prepareBase(up, localGet);

  say('Đang kiểm tra cập nhật...');
  const res = await up.update({ deadlineMs: cfg.updateBudgetMs || 20000 });
  if (res.status === 'shell-outdated') {
    await new Promise((resolve) => {
      $('need').hidden = false;
      $('store').onclick = () => openExternalNative(cfg.storeUrl || cfg.origin);
      $('cont').onclick = () => resolve();
    });
  } else if (res.status === 'rejected') console.warn('[nttl] cập nhật bị từ chối:', res.code, res.reason);

  const act = await up.beginLaunch();
  if (act.rolledBack) console.warn('[nttl] quay lui', act.rolledBack);
  await writeShellBridge(fs, cfg, act, new Uint8Array(await (await fetch('./nttl-shell.js')).arrayBuffer()));
  say('Đang vào game...');
  await openBundle(act.abs);
}

if (typeof document !== 'undefined') {
  main().catch((e) => { console.error(e); say('Lỗi khởi động: ' + (e && e.message || e)); $('retry').hidden = false; });
  $('retry').onclick = () => location.reload();
}
