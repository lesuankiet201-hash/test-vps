// Cầu nối lõi <-> plugin Capacitor (chạy trong WebView). Chỉ dùng window.Capacitor.Plugins:
// Filesystem (chính thức), CapacitorHttp (có sẵn trong core, gọi tường minh nên KHÔNG cần CORS), WebView (core), Browser, App.
import { ed25519 } from '@noble/curves/ed25519';
import { b64ToBytes, bytesToB64, utf8 } from '../core/util.js';

const P = () => window.Capacitor.Plugins;
const DIRECTORY = 'DATA'; // thư mục riêng của ứng dụng (Android: files/, iOS: Documents của sandbox, không chia sẻ)

export const sha256Hex = async (u8) => {
  const d = new Uint8Array(await crypto.subtle.digest('SHA-256', u8));
  return Array.from(d, (b) => b.toString(16).padStart(2, '0')).join('');
};
export const verifyEd25519 = async (sig, msg, pub) => ed25519.verify(sig, msg, pub);

/**
 * Đọc nhị phân không qua base64 (docs/he-thong/77 §2c): Filesystem.readFile trên Android / iOS luôn trả base64 (gói 5 MB = chuỗi 6,7 MB +
 * giải mã trên luồng chính). WebView của Capacitor phục vụ tệp trong máy qua `Capacitor.convertFileSrc(file://…)`
 * (https://localhost/_capacitor_file_/…) → fetch() lấy ArrayBuffer thẳng. Lỗi / nền không hỗ trợ thì quay về base64 như cũ.
 * Ghi vẫn base64 (plugin Filesystem chỉ nhận chuỗi trên máy thật) nhưng trang không chờ ghi (AssetStore.download: put không await).
 */
let fastRead = true;
async function readBinary(path) {
  const conv = window.Capacitor?.convertFileSrc;
  if (!fastRead || typeof conv !== 'function') return null;
  try {
    const { uri } = await P().Filesystem.getUri({ path, directory: DIRECTORY });
    const r = await fetch(conv(uri), { cache: 'no-store' });
    if (!r.ok) return null;
    return new Uint8Array(await r.arrayBuffer());
  } catch { fastRead = false; return null; } // một lần lỗi kiểu nền tảng (CORS / scheme): thôi thử, dùng base64
}

export const fs = {
  async readBytes(path) {
    const fast = await readBinary(path);
    if (fast) return fast;
    const r = await P().Filesystem.readFile({ path, directory: DIRECTORY });
    return b64ToBytes(r.data);
  },
  async writeBytes(path, u8) { await P().Filesystem.writeFile({ path, directory: DIRECTORY, data: bytesToB64(u8), recursive: true }); },
  async exists(path) { try { await P().Filesystem.stat({ path, directory: DIRECTORY }); return true; } catch { return false; } },
  async mkdir(path) { try { await P().Filesystem.mkdir({ path, directory: DIRECTORY, recursive: true }); } catch (e) { if (!(await this.exists(path))) throw e; } },
  async rename(from, to) {
    if (await this.exists(to)) await this.rm(to); // rename không ghi đè ở mọi nền tảng
    await P().Filesystem.rename({ from, to, directory: DIRECTORY, toDirectory: DIRECTORY });
  },
  async copy(from, to) { await P().Filesystem.copy({ from, to, directory: DIRECTORY, toDirectory: DIRECTORY }); },
  async rm(path) {
    if (!(await this.exists(path))) return;
    const s = await P().Filesystem.stat({ path, directory: DIRECTORY });
    if (s.type === 'directory') await P().Filesystem.rmdir({ path, directory: DIRECTORY, recursive: true });
    else await P().Filesystem.deleteFile({ path, directory: DIRECTORY });
  },
  async list(path) { const r = await P().Filesystem.readdir({ path, directory: DIRECTORY }); return r.files.map((f) => (typeof f === 'string' ? f : f.name)); },
  async abs(path) { const r = await P().Filesystem.getUri({ path, directory: DIRECTORY }); return decodeURI(r.uri.replace(/^file:\/\//, '')); },
};

/**
 * Chuyển kết quả CapacitorHttp (responseType 'blob') về byte gốc (docs/van-hanh/09 §5.2 B1). Capacitor 6 `HttpRequestHandler.readData`:
 *  - Content-Type chứa application/json  -> BỎ QUA responseType, trả JSON đã parse (object / mảng / số / bool / chuỗi bỏ ngoặc,
 *    hoặc chuỗi văn bản thô nếu parse lỗi) -> KHÔNG dựng lại được byte gốc (chữ ký Ed25519 + manifestSha256 tính trên byte gốc).
 *  - mã lỗi (>= 400)                      -> chuỗi văn bản thô (hoặc JSON đã parse).
 *  - còn lại                              -> chuỗi base64 (Base64.DEFAULT: có xuống dòng mỗi 76 ký tự).
 * Trả Uint8Array, hoặc null = phải lấy lại byte gốc bằng đường khác (fetch của WebView).
 */
export function capHttpBytes(r) {
  const h = r && r.headers || {};
  const ctKey = Object.keys(h).find((k) => k && k.toLowerCase() === 'content-type');
  const ct = String(ctKey ? h[ctKey] : '').toLowerCase();
  const d = r ? r.data : undefined;
  if (r && r.status >= 400) return typeof d === 'string' ? utf8(d) : utf8(d == null ? '' : JSON.stringify(d)); // thân lỗi: chỉ để báo, không kiểm chữ ký
  if (ct.includes('application/json') || typeof d !== 'string') return null;   // đã bị parse (hoặc dạng lạ): cần byte gốc
  try { return b64ToBytes(d.replace(/\s+/g, '')); } catch { return null; }    // không phải base64 -> văn bản thô: lấy lại byte gốc
}

/** net.get đọc byte thô BẤT KỂ Content-Type. capRequest = CapacitorHttp.request; rawFetch(url) -> {status, bytes} (fetch của WebView). */
export function createNet(capRequest, rawFetch) {
  return {
    async get(url) {
      const r = await capRequest({ url, method: 'GET', responseType: 'blob', headers: { 'Cache-Control': 'no-cache' }, connectTimeout: 15000, readTimeout: 30000 });
      const bytes = capHttpBytes(r);
      if (bytes) return { status: r.status, bytes };
      return rawFetch(url); // JSON đã bị parse: KHÔNG dựng lại từ object, gửi lại bằng fetch để lấy đúng byte (Nginx /bundle cho CORS https://localhost)
    },
  };
}

async function webviewFetchRaw(url) {
  const r = await fetch(url, { cache: 'no-store', credentials: 'omit' });
  return { status: r.status, bytes: new Uint8Array(await r.arrayBuffer()) };
}

/** HTTP native: không dính CORS của WebView, theo network_security_config / ATS (chỉ https). */
export const net = createNet((o) => P().CapacitorHttp.request(o), webviewFetchRaw);

export async function openBundle(absPath) { await P().WebView.setServerBasePath({ path: absPath }); } // KHÔNG persistServerBasePath: launcher luôn quyết định
export const openExternalNative = (url) => P().Browser.open({ url });
