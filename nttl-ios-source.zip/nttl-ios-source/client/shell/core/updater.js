// Lõi cập nhật nóng của vỏ Capacitor (docs/he-thong/57 §hợp đồng bundle). Thuần JS, phụ thuộc được tiêm vào:
//   fs  : { readBytes, writeBytes, exists, mkdir, rename, copy, rm, list, abs }  (đường dẫn tương đối thư mục riêng của app)
//   net : { get(url) -> { status, bytes } }  (ném lỗi nếu mất mạng)
//   sha256Hex(u8) -> Promise<hex>,  verifyEd25519(sig u8, msg u8, pub u8) -> boolean
// Thuật toán: latest.json -> manifest -> kiểm sha256 manifest -> KIỂM CHỮ KÝ -> so file với bản đang chạy ->
// tải CHỈ file đổi vào thư mục tạm -> kiểm sha256 + size -> đổi tên thư mục (nguyên tử) -> ghi state.
// Bản mới vào "thử" (trial): không báo ready thì quay lui bản trước. Vỏ KHÔNG giữ khóa giải mã gói.
import { b64ToBytes, canonicalJson, cmpBundleVersion, cmpVersion, fromUtf8, hexToBytes, isSha256, pool, safeRelPath, UpdateError, utf8 } from './util.js';

const ROOT = 'nttl';
const STATE = `${ROOT}/state.json`;
const MAX_TRIES = 2; // số lần khởi động thử bản mới mà chưa ready thì quay lui

export function createUpdater({ fs, net, sha256Hex, verifyEd25519, config, now = () => Date.now(), onProgress = () => {} }) {
  // config: { origin, keys:{keyId:base64pub}, shellVersion, parallel? }
  const origin = config.origin.replace(/\/+$/, '');
  const dirOf = (v) => `${ROOT}/bundles/${String(v).replace(/[^A-Za-z0-9._-]/g, '_')}`;

  // ---------- state (ghi 2 bước: .tmp rồi đổi tên; đọc có dự phòng .tmp) ----------
  async function loadState() {
    for (const p of [STATE, STATE + '.tmp']) {
      try {
        if (await fs.exists(p)) return JSON.parse(fromUtf8(await fs.readBytes(p)));
      } catch { /* thử bản kế */ }
    }
    return null; // chưa cài gì
  }
  async function saveState(st) {
    await fs.mkdir(ROOT);
    await fs.writeBytes(STATE + '.tmp', utf8(JSON.stringify(st)));
    await fs.rename(STATE + '.tmp', STATE);
  }

  // ---------- manifest ----------
  function parseManifest(raw) {
    let m;
    try { m = JSON.parse(fromUtf8(raw)); } catch { throw new UpdateError('bad-manifest', 'manifest không phải JSON'); }
    if (!m || m.format !== 2 || typeof m.files !== 'object' || !m.files || m.bundleVersion == null || !m.entry)
      throw new UpdateError('bad-manifest', 'manifest sai định dạng (cần format 2)');
    if (!(m.entry in m.files)) throw new UpdateError('bad-manifest', 'entry không nằm trong files');
    const seen = new Set();
    for (const [p, f] of Object.entries(m.files)) {
      if (!safeRelPath(p)) throw new UpdateError('bad-manifest', 'đường dẫn không an toàn: ' + p);
      const lc = p.toLowerCase();
      if (seen.has(lc)) throw new UpdateError('bad-manifest', 'trùng đường dẫn (khác hoa/thường): ' + p);
      seen.add(lc);
      if (!f || !isSha256(f.sha256) || !Number.isInteger(f.size) || f.size < 0) throw new UpdateError('bad-manifest', 'mục file hỏng: ' + p);
    }
    return m;
  }

  /** Chữ ký Ed25519 (base64, trường `signature`) trên JSON chuẩn hóa của manifest bỏ trường `signature`.
   *  GIẢ ĐỊNH chờ doc 57 của S: nếu S ký trên byte thô, chỉ cần sửa hàm này. */
  async function checkSignature(m) {
    // config.keys: mảng khóa công khai Ed25519 (raw 32 byte, hex 64 ký tự; định dạng gen-signing-key.mjs của S). Thử lần lượt (hỗ trợ xoay khóa ký).
    // `manifest.keyId` là id khóa AES của gói (đổi mỗi lần phát hành) — KHÔNG phải id khóa ký nên không dùng để chọn khóa.
    const keys = (config.keys || []).filter((k) => /^[0-9a-f]{64}$/.test(k || ''));
    if (!keys.length) throw new UpdateError('bad-signature', 'vỏ chưa có khóa công khai');
    if (typeof m.signature !== 'string') throw new UpdateError('bad-signature', 'manifest không có chữ ký');
    const { signature, ...rest } = m;
    const msg = utf8(canonicalJson(rest));
    let ok = false;
    for (const k of keys) {
      try { if (await verifyEd25519(b64ToBytes(signature), msg, hexToBytes(k))) { ok = true; break; } } catch { /* thử khóa kế */ }
    }
    if (!ok) throw new UpdateError('bad-signature', 'chữ ký manifest sai');
  }

  async function getOk(url) {
    let r;
    try { r = await net.get(url); } catch (e) { throw new UpdateError('offline', String(e && e.message || e)); }
    if (r.status < 200 || r.status >= 300) throw new UpdateError(r.status >= 500 ? 'offline' : 'bad-manifest', `HTTP ${r.status} ${url}`);
    return r.bytes;
  }

  // ---------- cài một bundle (dùng chung cho bản gốc và bản tải về) ----------
  // source.getFile(sha, size) -> Promise<Uint8Array> ; reuse: thư mục bản đang chạy + manifest của nó
  async function installBundle(m, rawManifest, getFile, reuse, deadline) {
    const dir = dirOf(m.bundleVersion), stage = `${ROOT}/stage/${String(m.bundleVersion).replace(/[^A-Za-z0-9._-]/g, '_')}`;
    if (await fs.exists(dir)) return { dir, downloaded: 0, reused: 0 }; // đã có đủ (chỉ đổi tên khi hoàn tất)
    await fs.mkdir(stage);
    const entries = Object.entries(m.files);
    let downloaded = 0, reused = 0, bytes = 0;
    const total = entries.reduce((s, [, f]) => s + f.size, 0);
    await pool(entries, config.parallel || 4, async ([path, f]) => {
      if (deadline && now() > deadline) throw new UpdateError('timeout', 'hết thời hạn tải');
      const dest = `${stage}/${path}`;
      // 1) đã có trong thư mục tạm từ lần đứt mạng trước và đúng hash -> giữ
      if (await fs.exists(dest)) {
        const have = await fs.readBytes(dest);
        if (have.length === f.size && (await sha256Hex(have)) === f.sha256) { reused++; bytes += f.size; onProgress({ bytes, total }); return; }
        await fs.rm(dest);
      }
      // 2) trùng với bản đang chạy (cùng đường dẫn, cùng hash) -> sao chép nội bộ, không tải
      const old = reuse && reuse.manifest.files[path];
      if (old && old.sha256 === f.sha256 && old.size === f.size && (await fs.exists(`${reuse.dir}/${path}`))) {
        await fs.mkdir(parent(dest));
        await fs.copy(`${reuse.dir}/${path}`, dest);
        reused++; bytes += f.size; onProgress({ bytes, total }); return;
      }
      // 3) tải, kiểm size + sha256 TRƯỚC khi ghi
      const data = await getFile(f.sha256, f.size);
      if (data.length !== f.size || (await sha256Hex(data)) !== f.sha256) throw new UpdateError('bad-hash', 'sai hash/size: ' + path);
      await fs.mkdir(parent(dest));
      await fs.writeBytes(dest, data);
      downloaded++; bytes += f.size; onProgress({ bytes, total });
    });
    await fs.writeBytes(`${stage}/.manifest.json`, rawManifest);
    await fs.mkdir(`${ROOT}/bundles`);
    await fs.rename(stage, dir); // nguyên tử: thư mục bundles/<ver> chỉ xuất hiện khi đủ và đã kiểm
    return { dir, downloaded, reused };
  }
  const parent = (p) => p.slice(0, p.lastIndexOf('/'));

  async function readInstalledManifest(dir) {
    try { return JSON.parse(fromUtf8(await fs.readBytes(`${dir}/.manifest.json`))); } catch { return null; }
  }

  /** Lần chạy đầu: dựng bản gốc từ gói trong ứng dụng (assets `base/`). Chữ ký vẫn được kiểm (cùng khóa). */
  async function installBase(baseGet) {
    const raw = await baseGet('manifest.json');
    const m = parseManifest(raw);
    await checkSignature(m);
    const r = await installBundle(m, raw, (sha) => baseGet(`f/${sha}`), null);
    const st = { active: { version: String(m.bundleVersion), dir: r.dir }, previous: null, trial: null, bad: [], shellMin: m.minShellVersion || '0' };
    await saveState(st);
    return st;
  }

  /** Mỗi lần khởi động (docs/van-hanh/09 §5.2 B2): chưa có gì -> cài bản gốc; bản gốc nhúng trong file cài MỚI HƠN bản đang dùng
   *  (người dùng cài đè APK mới, giữ dữ liệu) -> dựng lại từ bản nhúng. Không bao giờ hạ cấp; bản nằm trong danh sách xấu thì bỏ qua.
   *  Trả { action: 'installed' | 'upgraded' | 'kept', version }. */
  async function syncBase(baseGet) {
    const st = await loadState();
    if (!st) { const s = await installBase(baseGet); return { action: 'installed', version: s.active.version }; }
    const raw = await baseGet('manifest.json');
    const m = parseManifest(raw);
    const v = String(m.bundleVersion);
    // cmpBundleVersion trả 1 ở CẢ HAI chiều khi cùng phút khác hash (không rõ thứ tự): phải hơn hẳn, nếu không là có thể hạ cấp
    if (!(cmpBundleVersion(v, st.active.version) > 0 && cmpBundleVersion(st.active.version, v) < 0) || (st.bad || []).includes(v)) return { action: 'kept', version: st.active.version };
    await checkSignature(m);
    const cur = await readInstalledManifest(st.active.dir);
    const reuse = cur ? { dir: st.active.dir, manifest: cur } : null;
    const r = await installBundle(m, raw, (sha) => baseGet(`f/${sha}`), reuse);
    const next = { active: { version: v, dir: r.dir }, previous: st.active, trial: null, bad: st.bad || [], shellMin: m.minShellVersion || '0' };
    await saveState(next);
    await cleanup(next);
    return { action: 'upgraded', version: v, from: st.active.version };
  }

  async function cleanup(st) {
    const keep = new Set([st.active && st.active.dir, st.previous && st.previous.dir].filter(Boolean));
    try {
      for (const n of await fs.list(`${ROOT}/bundles`)) if (!keep.has(`${ROOT}/bundles/${n}`)) await fs.rm(`${ROOT}/bundles/${n}`);
    } catch { /* chưa có */ }
  }

  /** Kiểm + cài bản mới. Không bao giờ ném: trả {status}. status: up-to-date | updated | shell-outdated | offline | rejected | timeout */
  async function update({ deadlineMs } = {}) {
    const deadline = deadlineMs ? now() + deadlineMs : 0;
    try {
      const st = await loadState();
      if (!st) throw new UpdateError('bad-manifest', 'chưa có bản gốc');
      const latest = JSON.parse(fromUtf8(await getOk(`${origin}/bundle/latest.json?t=${now()}`)));
      if (latest.minShellVersion && cmpVersion(latest.minShellVersion, config.shellVersion) > 0)
        return { status: 'shell-outdated', minShellVersion: latest.minShellVersion };
      if (String(latest.bundleVersion) === st.active.version) return { status: 'up-to-date', version: st.active.version };
      if ((st.bad || []).includes(String(latest.bundleVersion))) return { status: 'rejected', code: 'known-bad', reason: 'bản này đã quay lui trước đó' };

      const raw = await getOk(`${origin}/bundle/manifest.json?t=${now()}`);
      if (latest.manifestSha256 && (await sha256Hex(raw)) !== latest.manifestSha256) throw new UpdateError('bad-hash', 'sha256 manifest khác latest.json');
      const m = parseManifest(raw);
      await checkSignature(m);                                   // KIỂM CHỮ KÝ trước mọi thứ khác
      if (latest.keyId != null && String(latest.keyId) !== String(m.keyId)) throw new UpdateError('bad-signature', 'keyId lệch latest.json');
      if (String(m.bundleVersion) !== String(latest.bundleVersion)) throw new UpdateError('bad-manifest', 'bundleVersion lệch latest.json');
      if (m.minShellVersion && cmpVersion(m.minShellVersion, config.shellVersion) > 0)
        return { status: 'shell-outdated', minShellVersion: m.minShellVersion };
      if (cmpBundleVersion(m.bundleVersion, st.active.version) <= 0) throw new UpdateError('downgrade', 'bản thấp hơn bản đang chạy (chống phát lại)');
      if ((st.bad || []).includes(String(m.bundleVersion))) return { status: 'rejected', code: 'known-bad' };

      const cur = await readInstalledManifest(st.active.dir);
      const reuse = cur ? { dir: st.active.dir, manifest: cur } : null;
      const r = await installBundle(m, raw, async (sha) => getOk(`${origin}/bundle/f/${sha}`), reuse, deadline);

      const next = { active: { version: String(m.bundleVersion), dir: r.dir }, previous: st.active, trial: { version: String(m.bundleVersion), attempts: 0 }, bad: st.bad || [], shellMin: m.minShellVersion || '0' };
      await saveState(next);
      await cleanup(next);
      return { status: 'updated', version: next.active.version, downloaded: r.downloaded, reused: r.reused };
    } catch (e) {
      if (e instanceof UpdateError) {
        if (e.code === 'offline' || e.code === 'timeout') return { status: e.code, reason: e.message };
        return { status: 'rejected', code: e.code, reason: e.message };
      }
      return { status: 'offline', reason: String(e && e.message || e) }; // JSON hỏng, lỗi đĩa...: giữ bản đang chạy
    }
  }

  /** Gọi mỗi lần khởi động (launcher): chọn bản để mở; bản thử quá MAX_TRIES lần chưa ready thì quay lui. */
  async function beginLaunch() {
    const st = await loadState();
    if (!st) throw new Error('chưa cài bản gốc');
    let rolledBack = null;
    if (st.trial && st.trial.version === st.active.version) {
      if (st.trial.attempts >= MAX_TRIES) { rolledBack = await rollbackIn(st, 'không báo ready sau ' + MAX_TRIES + ' lần mở'); }
      else { st.trial.attempts++; await saveState(st); }
    }
    return { version: st.active.version, dir: st.active.dir, abs: await fs.abs(st.active.dir), rolledBack, trial: !!st.trial };
  }

  async function rollbackIn(st, reason) {
    const bad = st.active.version;
    let prev = st.previous;
    if (!prev || !(await fs.exists(prev.dir))) throw new Error('không còn bản trước để quay lui');
    st.bad = [...new Set([...(st.bad || []), bad])];
    st.active = prev; st.previous = null; st.trial = null;
    await saveState(st);
    await cleanup(st);
    return { from: bad, to: prev.version, reason };
  }

  /** Trang báo "sẵn sàng": xác nhận bản (đúng version) và bỏ trạng thái thử. */
  async function confirmReady(version) {
    const st = await loadState();
    if (st && st.trial && st.trial.version === String(version)) { st.trial = null; await saveState(st); return true; }
    return false;
  }

  /** Trang tự quay lui (watchdog trong trang): trả đường dẫn tuyệt đối bản trước để vỏ mở lại. */
  async function rollback(version, reason) {
    const st = await loadState();
    if (!st || st.active.version !== String(version)) return null; // trang cũ, bản khác đã kích hoạt
    const r = await rollbackIn(st, reason || 'watchdog');
    return { ...r, abs: await fs.abs(st.active.dir) };
  }

  return { loadState, installBase, syncBase, update, beginLaunch, confirmReady, rollback, readInstalledManifest, _parseManifest: parseManifest };
}
