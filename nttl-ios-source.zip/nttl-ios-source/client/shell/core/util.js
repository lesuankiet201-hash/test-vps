// Tiện ích thuần JS dùng chung cho lõi cập nhật (chạy được trong WebView lẫn Node).

const HEX64 = /^[0-9a-f]{64}$/;
export const isSha256 = (s) => typeof s === 'string' && HEX64.test(s);

/** So sánh phiên bản dạng "1.2.3" / "2026.11.20-4" / số: từng đoạn, số so theo số, chữ so theo chữ. Trả <0, 0, >0. */
export function cmpVersion(a, b) {
  const seg = (v) => String(v).split(/[.\-+_]/).filter((x) => x !== '');
  const x = seg(a), y = seg(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    const p = x[i] ?? '0', q = y[i] ?? '0';
    const np = /^\d+$/.test(p), nq = /^\d+$/.test(q);
    if (np && nq) { const d = Number(p) - Number(q); if (d) return d; }
    else if (p !== q) return p < q ? -1 : 1;
  }
  return 0;
}

/** bundleVersion của S: "b-YYYYMMDD-HHMM-<hash8>". So theo mốc thời gian; cùng phút mà khác hash thì coi là mới hơn (không xác định được thứ tự). */
export function cmpBundleVersion(a, b) {
  const re = /^b-(\d{8}-\d{4})-/;
  const x = re.exec(String(a)), y = re.exec(String(b));
  if (x && y) { if (x[1] !== y[1]) return x[1] < y[1] ? -1 : 1; return String(a) === String(b) ? 0 : 1; }
  return cmpVersion(a, b);
}

export function hexToBytes(h) {
  const u8 = new Uint8Array(h.length / 2);
  for (let i = 0; i < u8.length; i++) u8[i] = parseInt(h.substr(i * 2, 2), 16);
  return u8;
}

/** Đường dẫn trong manifest phải tương đối, không "..", không "\", không ký tự điều khiển (chống ghi ra ngoài thư mục bundle). */
export function safeRelPath(p) {
  if (typeof p !== 'string' || !p || p.length > 300) return false;
  if (p.startsWith('/') || p.includes('\\') || /[\x00-\x1f]/.test(p)) return false;
  return p.split('/').every((s) => s !== '' && s !== '.' && s !== '..');
}

/** JSON chuẩn hóa: khóa sắp theo thứ tự, không khoảng trắng — dùng để ký / kiểm chữ ký manifest. */
export function canonicalJson(v) {
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return '[' + v.map(canonicalJson).join(',') + ']';
  return '{' + Object.keys(v).sort().map((k) => JSON.stringify(k) + ':' + canonicalJson(v[k])).join(',') + '}';
}

export const utf8 = (s) => new TextEncoder().encode(s);
export const fromUtf8 = (u8) => new TextDecoder().decode(u8);

export function b64ToBytes(b64) {
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}
export function bytesToB64(u8) {
  let s = '';
  for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
  return btoa(s);
}

/** Chạy tối đa n việc song song; một việc lỗi thì dừng nhận việc mới và ném lỗi đầu tiên. */
export async function pool(items, n, fn) {
  let i = 0, failed = null;
  const worker = async () => {
    while (!failed && i < items.length) {
      const item = items[i++];
      try { await fn(item); } catch (e) { failed = failed || e; }
    }
  };
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, worker));
  if (failed) throw failed;
}

export class UpdateError extends Error {
  /** code: offline | bad-signature | bad-manifest | bad-hash | downgrade | bad-version | timeout | shell-outdated */
  constructor(code, msg) { super(msg || code); this.code = code; }
}
