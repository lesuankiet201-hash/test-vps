// Kho đệm gói tài nguyên: CHỈ lưu ciphertext (AES-256-GCM) theo sha256 của chính ciphertext. Vỏ không giữ khóa.
// Có giới hạn dung lượng, dọn theo LRU. Dữ liệu nằm trong thư mục riêng của ứng dụng (không ai khác đọc được trên máy chưa root).
// Không chặn nhau (docs/he-thong/77 §2c): chỉ mục đọc MỘT lần vào RAM; has() trả theo chỉ mục RAM (không đụng đĩa) để trang đi thẳng ra
// mạng khi gói chưa có; get / put của các sha KHÁC nhau chạy song song (chỉ cùng sha mới xếp hàng); chỉ mục ghi theo lô (gộp mọi thay
// đổi trong SAVE_MS, một lần ghi đang chạy thì lần sau chờ nó).
import { fromUtf8, isSha256, utf8 } from './util.js';

const DIR = 'nttl/packs', INDEX = 'nttl/packs-index.json';

export function createPackCache({ fs, sha256Hex, quotaBytes = 256 * 1024 * 1024, now = () => Date.now(), saveMs = 400 }) {
  let idx = null, loadP = null;
  const lanes = new Map(); // sha -> promise cuối của làn sha đó
  const lane = (sha, fn) => {
    const prev = lanes.get(sha) ?? Promise.resolve();
    const p = prev.then(fn, fn);
    const tail = p.catch(() => {});
    lanes.set(sha, tail);
    tail.then(() => { if (lanes.get(sha) === tail) lanes.delete(sha); });
    return p;
  };
  const load = () => {
    if (idx) return Promise.resolve(idx);
    return (loadP ??= (async () => {
      try { idx = JSON.parse(fromUtf8(await fs.readBytes(INDEX))); } catch { idx = {}; }
      if (!idx || typeof idx !== 'object') idx = {};
      return idx;
    })());
  };
  // ghi chỉ mục theo lô
  let dirty = false, timer = null, saving = null;
  const writeNow = async () => {
    timer = null;
    if (saving) { await saving.catch(() => {}); }
    if (!dirty) return;
    dirty = false;
    saving = (async () => { await fs.mkdir('nttl'); await fs.writeBytes(INDEX, utf8(JSON.stringify(idx))); })();
    try { await saving; } finally { saving = null; }
  };
  const touch = () => { dirty = true; if (!timer) timer = setTimeout(() => { writeNow().catch(() => {}); }, saveMs); };
  const flush = async () => { if (timer) { clearTimeout(timer); timer = null; } await writeNow(); };
  const check = (sha) => { if (!isSha256(sha)) throw new TypeError('sha256 không hợp lệ'); };
  const used = () => Object.values(idx).reduce((s, e) => s + e.size, 0);

  return {
    /** Theo chỉ mục RAM (không đọc đĩa). Tệp mất ngoài ý muốn thì get() trả null và tự bỏ khỏi chỉ mục. */
    has: async (sha) => { check(sha); await load(); return !!idx[sha]; },
    get: async (sha) => { check(sha); return lane(sha, async () => {
      await load();
      if (!idx[sha]) return null;
      try {
        const data = await fs.readBytes(`${DIR}/${sha}`);
        if ((await sha256Hex(data)) !== sha) { delete idx[sha]; touch(); await fs.rm(`${DIR}/${sha}`).catch(() => {}); return null; } // hỏng -> bỏ
        if (idx[sha]) { idx[sha].t = now(); touch(); }
        return data;
      } catch { delete idx[sha]; touch(); return null; }
    }); },
    put: async (sha, bytes) => { check(sha); return lane(sha, async () => {
      await load();
      const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
      if (u8.length > quotaBytes) throw new RangeError('gói lớn hơn hạn mức kho đệm');
      if ((await sha256Hex(u8)) !== sha) throw new Error('sha256 không khớp, từ chối lưu');
      // chọn tệp cần dọn NGAY trên chỉ mục RAM (đồng bộ, không xen với put khác), rồi mới xóa / ghi đĩa
      let u = used() - (idx[sha] ? idx[sha].size : 0);
      const victims = Object.entries(idx).filter(([k]) => k !== sha).sort((a, b) => a[1].t - b[1].t);
      const gone = [];
      while (u + u8.length > quotaBytes && victims.length) { const [k, e] = victims.shift(); delete idx[k]; u -= e.size; gone.push(k); }
      if (gone.length) touch();
      for (const k of gone) await fs.rm(`${DIR}/${k}`).catch(() => {}); // không chờ làn của k: hai put dọn chéo nhau không kẹt
      await fs.mkdir(DIR);
      await fs.writeBytes(`${DIR}/${sha}`, u8);
      idx[sha] = { size: u8.length, t: now() };
      touch();
    }); },
    usage: async () => { await load(); return used(); },
    /** Ghi chỉ mục ngay (thoát app / test). */
    flush,
  };
}

/** openExternal chỉ cho https://, không user:pass@, không địa chỉ nội bộ/ip thô. */
export function safeExternalUrl(url) {
  let u;
  try { u = new URL(String(url)); } catch { return null; }
  if (u.protocol !== 'https:' || u.username || u.password) return null;
  const h = u.hostname;
  if (h === 'localhost' || /^[\d.]+$/.test(h) || h.includes(':') || !h.includes('.')) return null;
  return u.href;
}
