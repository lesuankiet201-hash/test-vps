// Chuẩn bị vỏ Capacitor: node shell/scripts/prepare.mjs [--dev] [--base <thư mục bundle gốc>] [--allow-placeholder]
//  - đóng gói launcher.js + nttl-shell.js (esbuild) vào client/shell-www/
//  - ghi shell-www/shell-config.json, capacitor.config.json (release/dev), network_security_config.xml theo miền
//  - chép bundle gốc (thư mục có manifest.json + f/) vào shell-www/base/
// Sau đó: npx cap sync android|ios
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const here = path.dirname(fileURLToPath(import.meta.url));
const client = path.resolve(here, '../..');
const args = process.argv.slice(2);
const flag = (n) => args.includes(n);
const arg = (n) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : null; };
const dev = flag('--dev');

const cfgPath = arg('--config') ? path.resolve(arg('--config')) : path.join(here, '../config/shell.config.json');
const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
delete cfg._ghi_chu;
if (!dev && !flag('--allow-placeholder')) {
  if (!cfg.keys.length) throw new Error('shell.config.json: keys rỗng (cần khóa công khai Ed25519 thật) — bản phát hành bị chặn');
  if (/example\.com/.test(cfg.origin)) throw new Error('shell.config.json: origin còn là miền mẫu');
  if (!arg('--base')) throw new Error('thiếu --base <bundle gốc>');
}
if (!dev && !/^https:\/\/[^/]+$/.test(cfg.origin)) throw new Error('origin phải là https://miền (không đường dẫn)');
const host = new URL(cfg.origin).hostname;

const out = path.join(client, 'shell-www');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

const common = { bundle: true, format: 'iife', minify: !dev, sourcemap: false, target: 'es2020', logLevel: 'warning', absWorkingDir: client };
await build({ ...common, entryPoints: ['shell/capacitor/launcher.js'], outfile: path.join(out, 'launcher.js') });
await build({ ...common, entryPoints: ['shell/capacitor/page.js'], outfile: path.join(out, 'nttl-shell.js') });
// CSP launcher: cho fetch tới đúng origin (net.get lấy lại byte gốc khi CapacitorHttp đã parse JSON, docs/van-hanh/09 §5.2)
const html = fs.readFileSync(path.join(here, '../www/index.html'), 'utf8');
if (!html.includes('__NTTL_ORIGIN__')) throw new Error('www/index.html thiếu __NTTL_ORIGIN__ trong CSP');
fs.writeFileSync(path.join(out, 'index.html'), html.replace('__NTTL_ORIGIN__', new URL(cfg.origin).origin));
fs.writeFileSync(path.join(out, 'shell-config.json'), JSON.stringify(cfg, null, 2));

const base = arg('--base');
if (base) {
  const src = path.resolve(base);
  if (!fs.existsSync(path.join(src, 'manifest.json'))) throw new Error('--base thiếu manifest.json');
  // chỉ chép manifest + các file thường nó liệt kê (KHÔNG chép p/ — gói mã hóa không được nằm trong file cài, doc 57 §1)
  const m = JSON.parse(fs.readFileSync(path.join(src, 'manifest.json'), 'utf8'));
  fs.mkdirSync(path.join(out, 'base/f'), { recursive: true });
  fs.copyFileSync(path.join(src, 'manifest.json'), path.join(out, 'base/manifest.json'));
  for (const f of Object.values(m.files)) fs.copyFileSync(path.join(src, 'f', f.sha256), path.join(out, 'base/f', f.sha256 + '.bin')); // đuôi .bin: WebView Capacitor chèn script vào file không đuôi (coi là HTML) làm sai hash
  console.log(`[prepare] bundle gốc ${m.bundleVersion}: ${Object.keys(m.files).length} file`);
}

// capacitor.config.json: bản phát hành là mặc định được commit; --dev ghi bản dev (đừng commit)
const capCfg = dev
  ? { appId: cfg.appId + '.dev', appName: cfg.appName + ' (dev)', webDir: 'shell-www', server: { androidScheme: 'http', cleartext: true }, android: { allowMixedContent: true, webContentsDebuggingEnabled: true } }
  : { appId: cfg.appId, appName: cfg.appName, webDir: 'shell-www', loggingBehavior: 'none',
      server: { androidScheme: 'https', cleartext: false },
      android: { allowMixedContent: false, webContentsDebuggingEnabled: false, captureInput: false },
      // never: trang tự né tai thỏ bằng env(safe-area-inset-*); 'always' làm vỏ chừa thêm lần nữa → vệt trắng hai bên + HUD thụt (docs/van-hanh/09 §5.4)
      ios: { contentInset: 'never', backgroundColor: '#000000', limitsNavigationsToAppBoundDomains: false } };
fs.writeFileSync(path.join(client, 'capacitor.config.json'), JSON.stringify(capCfg, null, 2) + '\n');

// network_security_config (Android): chỉ https tới miền cấu hình, không tin chứng chỉ người dùng cài
const nsc = `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors><certificates src="system" /></trust-anchors>
    </base-config>
    <domain-config cleartextTrafficPermitted="false">
        <domain includeSubdomains="true">${host}</domain>
    </domain-config>
</network-security-config>
`;
const nscPath = path.join(client, 'android/app/src/main/res/xml/network_security_config.xml');
fs.mkdirSync(path.dirname(nscPath), { recursive: true }); // gói bàn giao iOS không có thư mục android/
fs.writeFileSync(nscPath, nsc);
console.log(`[prepare] ${dev ? 'DEV' : 'RELEASE'} origin=${cfg.origin} appId=${capCfg.appId} base=${base || '(không)'}`);
